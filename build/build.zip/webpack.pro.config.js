module.exports = {
  plugins: [
    new CleanWebpackPlugin()
  ]
}