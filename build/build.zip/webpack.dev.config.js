module.exports = {
  devtool: 'cheap-module-eval-source-map'
}